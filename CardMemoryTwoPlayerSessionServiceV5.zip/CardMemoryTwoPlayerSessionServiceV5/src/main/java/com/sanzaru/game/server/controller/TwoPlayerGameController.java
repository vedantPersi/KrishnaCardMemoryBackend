package com.sanzaru.game.server.controller;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sanzaru.domain.model.card.Card;
import com.sanzaru.domain.model.game.GameStatus;
import com.sanzaru.game.server.service.GameService;
@CrossOrigin (origins = "http://localhost:3000")
@RestController
@RequestMapping("/")
public class TwoPlayerGameController {

	@Autowired
	private GameService gameService;

	/**
	 * RETURNS STATUS OF AVAILABLE GAMES
	 * 
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public Set<String> visit() {
		return gameService.gamesInWaiting();
	}

	/**
	 * RETURNS STATUS OF AVAILABLE GAMES
	 * 
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/gamestatus/{playerName}", method = RequestMethod.GET)
	public GameStatus refresh(@PathVariable("playerName") String playerName) {
		System.out.println("IN GAME STATUS");
		return gameService.currentGameStatus(playerName);
	}

	/**
	 * FIRST PLAYER REGISTERS FOR GAME
	 * 
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/newgame/{playerName}", method = RequestMethod.POST)
	public String register(@PathVariable("playerName") String playerName) {
		return gameService.newGame(playerName);
	}

	/**
	 * SECOND PLAYER REGISTERS FOR GAME
	 * 
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/register/{playerName}/{gameId}", method = RequestMethod.POST)
	public boolean register(@PathVariable("playerName") String playerName, @PathVariable("gameId") String gameId) {
		return gameService.registerOpponent(playerName, gameId);
	}

	/**
	 * RETURNS STATUS OF AVAILABLE GAMES
	 * 
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/start/{playerName}", method = RequestMethod.GET)
	public List<Card> start(@PathVariable("playerName") String playerName) {
		return gameService.start(playerName);
	}

	@RequestMapping(value = "/pickedcards/{index1}/{index2}/{playerName}", method = RequestMethod.POST)
	public Object checkForPair(@PathVariable("index1") int index1, @PathVariable("index2") int index2,
			@PathVariable("playerName") String playerName) {
		return gameService.checkForPair(index1, index2, playerName);
	}

//	@RequestMapping("/reset")
//	public List<Card> reset(HttpSession session) {
//	}

}
