package com.sanzaru.game.server.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.springframework.stereotype.Service;

import com.sanzaru.domain.model.card.Card;
import com.sanzaru.domain.model.game.Game;
import com.sanzaru.domain.model.game.GameRegistry;
import com.sanzaru.domain.model.game.GameStatus;
import com.sanzaru.domain.model.game.Player;

@Service
public class GameService {
	public Set<String> gamesInWaiting() {
		GameRegistry registry = GameRegistry.instance();
		return new TreeSet<String>(registry.allGames());
	}

	public GameStatus currentGameStatus(String playerName) {
		GameRegistry registry = GameRegistry.instance();
//		Player player = registry.getPlayer(playerName);
		Game currentGame = registry.associatedGame(playerName);
		return currentGame.getStatus();
	}
	
	public String newGame(String playerName) {
		String gameId = "";
		GameRegistry registry = GameRegistry.instance();
		Game newGame = registry.newInstance(playerName);
		if (newGame != null) {
			gameId = newGame.getId();
		}
		return gameId;
	}

	public boolean registerOpponent(String playerName, String gameId) {
		GameRegistry registry = GameRegistry.instance();
		Game game = registry.getGameInstance(gameId);
		boolean status = registry.registerPlayer(playerName, gameId);
		return status;
	}

	public List<Card> start(String playerName) {
		GameRegistry registry = GameRegistry.instance();
		Player player = registry.getPlayer(playerName);
		if (player.isActive()) {
			Game currentGame = registry.getGameInstance("game-of-" + playerName);
			return currentGame.start();
		}
		return new ArrayList<Card>(); // TODO SEND SPECIFIC ERROR MESSAGE
	}

	public List<Object> checkForPair(int index1, int index2, String playerName) {
		GameRegistry registry = GameRegistry.instance();
		Player player = registry.getPlayer(playerName);
		Game currentGame = registry.associatedGame(playerName);
		if (player.isActive()) {
			if (currentGame.markPair(index1, index2)) {
				player.addPoint();
			} 
			currentGame.nextPlayer();
		}
		List<Object> response = Arrays.asList(currentGame.availableCards(), Integer.valueOf(player.getPoints()), currentGame.getCurrentState());
		return response;
	}
}
