package com.sanzaru.game.server.model;

public class Name {
	private String fName;
	private String lName;
	
}
