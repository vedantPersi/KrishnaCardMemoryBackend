package com.sanzaru.game.server.model;

public enum State {
	WAITING_FOR_PLAYER, READY_TO_START, IN_PROGRESS, FINISHED;
}
