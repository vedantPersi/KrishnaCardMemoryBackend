package com.sanzaru.game.server.model;


public class Card implements Cloneable, Comparable<Card>{
	private Suit suit;
	private Rank rank;
	private boolean active = true;
	public Card(){}
	public Card(Suit suit, Rank rank) {
		super();
		this.suit = suit;
		this.rank = rank;
	}

	public boolean isMatchingSuit(Card other){
		return this.suit.equals(other.suit);
	}

	public boolean isMatchingRank(Card other){
		return this.rank.equals(other.rank);
	}
	
	public void markInactive(){
		this.active = false;
	}
	
	@Override
	public int compareTo(Card other) {
		if (this.rank.compareTo(other.rank) == 0){
			return this.suit.compareTo(other.suit);
		} else {
			return this.rank.compareTo(other.rank);
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((rank == null) ? 0 : rank.hashCode());
		result = prime * result + ((suit == null) ? 0 : suit.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Card other = (Card) obj;
		return this.compareTo(other) == 0;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("(");
		builder.append(suit);
		builder.append(", ");
		builder.append(rank);
		builder.append(")");
		return builder.toString();
	}
	
	public Suit getSuit() {
		return suit;
	}
	public void setSuit(Suit suit) {
		this.suit = suit;
	}
	public Rank getRank() {
		return rank;
	}
	public void setRank(Rank rank) {
		this.rank = rank;
	}
		
	public boolean isActive(){
		return active;
	}

}
