package com.sanzaru.game.server.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sanzaru.game.server.model.Card;
import com.sanzaru.game.server.model.Rank;
import com.sanzaru.game.server.model.State;
import com.sanzaru.game.server.model.Suit;
@CrossOrigin (origins = "http://localhost:3000")
@RestController
@RequestMapping("/")
public class TwoPlayerGameController_template {

//	@Autowired
//	private GameService gameService;

/*
 * TEST URLS WITH HARD CODED RESPONSES
-----------------------------------
1. http://localhost:8080/ -> gives list of games
2. http://localhost:8080/newgame/Suresh ->
    returns newly created game name
3. http://localhost:8080/register/Ramesh/game-of-Suresh ->
    returns success status of registration true
4. http://localhost:8080/pickedcards/9/10/Suresh -> 
    request to check 9th and 10th card by Suresh
    returns cards with 9th and 10th cards inactive
 * 
 */
	
	/**
	 * RETURNS STATUS OF AVAILABLE GAMES
	 * 
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public Set<String> visit() {
		return new TreeSet<String>(Arrays.asList("game-of-Suresh", "game-of-Ramesh", "game-of-Haresh"));
	}

	/**
	 * FIRST PLAYER REGISTERS FOR GAME
	 * 
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/newgame/{playerName}", method = RequestMethod.POST)
	public String register(@PathVariable("playerName") String playerName) {
		return "game-of-" + playerName;
	}

	/**
	 * SECOND PLAYER REGISTERS FOR GAME
	 * 
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/register/{playerName}/{gameId}", method = RequestMethod.POST)
	public boolean register(@PathVariable("playerName") String playerName, @PathVariable("gameId") String gameId) {
		return true;
	}

	/**
	 * RETURNS STATUS OF AVAILABLE GAMES
	 * 
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/start/{playerName}", method = RequestMethod.GET)
	public List<Card> start(@PathVariable("playerName") String playerName) {
		List<Card> cards = new ArrayList<>();
		for (Suit suit: Suit.values()) {
			for (Rank rank: Rank.values()) {
				cards.add(new Card(suit, rank));
			}
		}
		return cards;
	}

	@RequestMapping(value = "/pickedcards/{index1}/{index2}/{playerName}", method = RequestMethod.POST)
	public Object checkForPair(@PathVariable("index1") int index1, @PathVariable("index2") int index2,
			@PathVariable("playerName") String playerName) {
		// TODO WE NEED TO SEND THREE THINGS 1.CARDS  2.CURRENT PLAYERS POINTS  3.GAME STATUS {WAITING, IN_PROGRESS, FINISHED} 
		List<Card> cards = new ArrayList<>();
		for (Suit suit: Suit.values()) {
			for (Rank rank: Rank.values()) {
				cards.add(new Card(suit, rank));
			}
		}
		
		cards.get(9).markInactive();
		cards.get(10).markInactive();

		//                                                     (cards, points, status as enum)
		List<Object> response = Arrays.asList(cards, 1,         State.IN_PROGRESS);
		return response;
	}

//	@RequestMapping("/reset")
//	public List<Card> reset(HttpSession session) {
//	}

}
