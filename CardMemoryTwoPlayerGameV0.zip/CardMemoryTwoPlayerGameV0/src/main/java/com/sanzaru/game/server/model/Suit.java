package com.sanzaru.game.server.model;

public enum Suit {
	CLUB(3), DIAMOND(2), HEART(1), SPADE(0);
	private int position;
	private Suit(int position){
		this.position = position;
	}
	public int getPosition() {
		return position;
	}
	public void setPosition(int position) {
		this.position = position;
	}
	
}
